set lines 400
set pages 200
prompt ========================================================================
prompt == Exibe a versao do banco de dados
prompt ========================================================================
prompt

col banner_full form a120
select banner_full from v$version;
