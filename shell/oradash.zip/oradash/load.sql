set lines 400
set pages 200
prompt ========================================================================
prompt == Informacoes gerais sobre o load do banco nos ultimos 15 minutos
prompt ========================================================================
prompt

set pages 200
col begin_time form a25
col metric_name form a25


-- Define os cabeçalhos com quebras de linha
COL "Average Active Sessions"  HEADING 'Average Active| Sessions'
COL "Host CPU Utilization (%)" HEADING 'Host CPU| Utilization (%)'
COL "Database CPU Time Ratio"  HEADING 'Database CPU| Time Ratio'
COL "Database Wait Time Ratio" HEADING 'Database Wait| Time Ratio'
COL "Executions Per Sec"       HEADING 'Executions| Per Sec' form 999,999,999
COL "I/O Megabytes per Second" HEADING 'I/O Megabytes| per Second' form 999,999,999
COL "Logons Per Sec"           HEADING 'Logons| Per Sec' form 999,999,999

SELECT *
FROM (
  SELECT 
    to_char(begin_time,'DD/MM/RRRR HH24:MI') AS begin_time,
    metric_name,
    round(value,2) AS value
  FROM gV$SYSMETRIC_HISTORY
  WHERE metric_name IN (
          'Average Active Sessions',
          'Host CPU Utilization (%)',
          'Database CPU Time Ratio',
          'Database Wait Time Ratio',
          'Executions Per Sec',
          'I/O Megabytes per Second',
          'Logons Per Sec'
        )
    AND group_id = 2
    AND begin_time >= sysdate - (15/1440)
)
PIVOT (
  MAX(value) FOR metric_name IN (
    'Average Active Sessions' AS "Average Active Sessions",
    'Host CPU Utilization (%)' AS "Host CPU Utilization (%)",
    'Database CPU Time Ratio' AS "Database CPU Time Ratio",
    'Database Wait Time Ratio' AS "Database Wait Time Ratio",
    'Executions Per Sec' AS "Executions Per Sec",
    'I/O Megabytes per Second' AS "I/O Megabytes per Second",
    'Logons Per Sec' AS "Logons Per Sec"
  )
)
ORDER BY begin_time;