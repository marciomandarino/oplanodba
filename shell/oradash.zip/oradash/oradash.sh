#!/bin/bash

# ANSI Colors (usando $'...' para interpretar os escapes corretamente)
BLUE=$'\e[34m'
RED=$'\e[31m'
GREEN=$'\e[32m'
MAGENTA=$'\e[35m'
CYAN=$'\e[36m'
YELLOW=$'\e[33m'
RESET=$'\e[0m'

# Função para centralizar uma linha interna do cabeçalho.
# A linha inicia com "#." e termina com "#" e o conteúdo é centralizado no espaço restante (134 - 3 = 131 caracteres).
center_line() {
    local text="$1"
    local width=134
    local inner_width=$((width - 3))
    local text_length=${#text}
    local padding=$(( (inner_width - text_length) / 2 ))
    local extra=$(( (inner_width - text_length) % 2 ))
    printf "#.%*s%s%*s#\n" "$padding" "" "$text" "$((padding + extra))" ""
}

# Função para imprimir o cabeçalho centralizado com 134 caracteres
print_header() {
    local width=134
    local border
    border=$(printf '%*s' "$width" "" | tr ' ' '#')
    echo "$border"
    center_line "  ___  ____     _    ____    _    ____  _   _ "
    center_line " / _ \|  _ \   / \  |  _ \  / \  / ___|| | | |"
    center_line "| | | | |_) | / _ \ | | | |/ _ \ \___ \| |_| |"
    center_line "| |_| |  _ < / ___ \| |_| / ___ \ ___) |  _  |"
    center_line " \___/|_| \_/_/   \_|____/_/   \_|____/|_| |_|"
    center_line "                                              "
    center_line "ORADASH"
    center_line "Oracle Interactive Dashboard and Tools"
    echo "$border"


                                              






                       
                               

}

# Função para imprimir uma linha de menu com 4 colunas (cada coluna com 35 caracteres)
print_menu_row() {
    # $1, $2, $3, $4 são as strings de cada coluna
    printf "%-35s%-35s%-35s%-35s\n" "$1" "$2" "$3" "$4"
}

while true; do
    clear
    print_header
    echo

    # Exibe ORACLE_HOME e ORACLE_SID (em maiúsculas) na mesma linha; 
    # o ORACLE_SID ativo é destacado em MAGENTA (aqui os códigos de cor não afetam o alinhamento, pois são externos ao printf)
    echo "ORACLE_HOME: ${ORACLE_HOME^^} | ORACLE_SID: ${MAGENTA}${ORACLE_SID^^}${RESET}"
    echo

    # Listagem dos databases encontrados (em uma única linha)
    echo -n "Databases encontrados no oratab: "
    for sid in $(grep -Ev '^#|^$' /etc/oratab | cut -d: -f1); do
        if pgrep -f "ora_pmon_${sid}" &>/dev/null; then 
            echo -n "${GREEN}${sid}${RESET}  "
        else 
            echo -n "${RED}${sid}${RESET}  "
        fi
    done
    echo
    echo "_____________________________________________________________________________________________________________________________________"
    echo

    # Categoria extra: Ferramentas úteis
    echo -e "${CYAN}FERRAMENTAS ÚTEIS:${RESET}"
    echo "S) SQLPLUS                    R) RMAN                     A) ADRCI                            O) ORATOP"
    echo

    # Categoria 1: Backup/Recovery
    echo -e "${CYAN}BACKUP/RECOVERY:${RESET}"
    
    echo "1.1) Backups (24h)            1.2) Archives (24h)         1.3) Backups Full/Incr (7 dias)     1.4) Espaço na FRA"
    echo

    # Categoria 2: Performance
    echo -e "${CYAN}PERFORMANCE:${RESET}"
    echo "2.1) Load do banco            2.2) Relatório ASH          2.3) Waits do banco                 2.4) AWR Report (última hora)"
    echo "2.5) AWR Report               2.6) Bloqueios ativos       2.7) Sessões ativas                 2.8) Memória (SGA/PGA)"
    echo

    # Categoria 3: Informações do Banco
    echo -e "${CYAN}INFORMAÇÕES DO BANCO:${RESET}"
    echo "3.1) Info. do Database        3.2) Status do database     3.3) Tablespaces                    3.4) PDBs"
    echo "3.5) Ocupação do Database     3.6) Últimos jobs           3.7) Tempo online                   3.8) Versão do Oracle"
    echo

    # Categoria 4: SO
    echo -e "${CYAN}SO:${RESET}"
    echo "4.1) Resumo do Sistema        4.2) Alert log (vim)        4.3) Alert log (tail -f)            4.4) Espaço em disco"
    echo "4.5) Load do sistema          4.6) Monitoramento (top)    4.7) Logs do Sistema                4.8) Listener (via SO)"
    echo

    # Opções finais: Sair, Alternar Database e Créditos
    echo -e "0) Sair                       ${GREEN}D) Alternar Database${RESET}        99) Créditos"
    echo
    read -p "Escolha uma opção: " opcao
    clear

    case "$opcao" in
        [Dd])
            clear
# Função para remover os códigos ANSI de uma string
strip_ansi() {
    echo "$1" | sed 's/\x1B\[[0-9;]*[a-zA-Z]//g'
}
echo "------------------------------------------------------------------------------"
echo " Alternar Database - Selecione um SID"
echo "------------------------------------------------------------------------------"

dbs=()
homes=()
while IFS=: read -r sid home auto; do
    [[ -z "$sid" || "$sid" =~ ^# ]] && continue
    dbs+=("$sid")
    homes+=("$home")
done < <(grep -Ev '^#|^$' /etc/oratab)

total=${#dbs[@]}
for idx in "${!dbs[@]}"; do
    num=$((idx+1))
    sid="${dbs[$idx]}"
    home="${homes[$idx]}"
    # Define a cor: se online, verde; senão, vermelho.
    if pgrep -f "ora_pmon_${sid}" &>/dev/null; then
        color="$GREEN"
    else
        color="$RED"
    fi
    # Se for o banco atual, adiciona o asterisco
    if [ "$sid" = "$ORACLE_SID" ]; then
        display_sid="${sid}*"
    else
        display_sid="$sid"
    fi
    # Remove os códigos ANSI para calcular o padding
    plain_sid=$(echo "$display_sid" | sed 's/\x1B\[[0-9;]*[a-zA-Z]//g')
    padded_sid=$(printf "%-10s" "$plain_sid")
    printf "%-4s %-10s Home: %-40s\n" "$num)" "${color}${padded_sid}${RESET}" "$home"
done
echo " "
echo "0) Manter o database atual e voltar ao menu anterior"
echo " "
echo " "
read -p "Digite o número da instância desejada: " escolha
if [ "$escolha" = "0" ]; then
    continue
fi
index=$((escolha-1))
if [[ $index -ge 0 && $index -lt ${#dbs[@]} ]]; then
    novo_sid="${dbs[$index]}"
    novo_home="${homes[$index]}"
    echo -e "Você escolheu: ${novo_sid}* Home: ${novo_home}"
    export ORACLE_SID="$novo_sid"
    export ORACLE_HOME="$novo_home"
    . oraenv <<< "$novo_sid"
    echo "Ambiente atualizado!"
    sleep 2
else
    echo "Opção inválida."
    sleep 2
fi



		;;
        99)
            echo "================================"
            echo "            CRÉDITOS            "
            echo "================================"
            echo "Desenvolvido por: Seu Nome"
            echo "Email: seu.email@dominio.com"
            echo "GitHub: https://github.com/seunome"
            echo ""
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        0)
            echo "Saindo..."
            break
            ;;
        S|s)
            echo "Abrindo SQLPLUS..."
            sqlplus / as sysdba
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        R|r)
            echo "Executando RMAN..."
            rman target /
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        A)
            echo "Executando ADRCI..."
            adrci
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        O|o)
            echo "Executando ORATOP..."
            $ORACLE_HOME/suptools/oratop/oratop -rf / as sysdba
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "1.1")
            echo "Executando script: Backups (24h)..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/backup_day.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "1.2")
            echo "Executando script: Archives gerados (24h)..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/archives_lastday.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "1.3")
            echo "Executando script: Backups Full/Incr (7 dias)..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/backup_week.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "1.4")
            echo "Executando script: Espaço na FRA..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/fra.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.1")
            echo "Executando script: Load do banco..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/load.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.2")
            echo "Executando script: Relatório ASH..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/ash_report.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.3")
            echo "Executando script: Waits do banco..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/ash.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.4")
            echo "Executando script: AWR Report (última hora)..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/awr_1hora.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.5")
            echo "Executando script: AWR Report..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/awr.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.6")
            echo "Executando script: Bloqueios ativos..."
            sqlplus -s / as sysdba <<EOF
@$ORACLE_HOME/rdbms/admin/utllockt.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.7")
            echo "Executando script: Sessões ativas..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/active_sessions.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "2.8")
            echo "Executando script: Memória (SGA/PGA)..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/memoria.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.1")
            echo "Executando script: Info. do Database..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/aonde.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.2")
            echo "Executando script: Status do database..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/status_db.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.3")
            echo "Executando script: Tablespaces..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/ts.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.4")
            echo "Executando script: PDBs..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/pdb_info.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.5")
            echo "Executando script: Ocupação do Database..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/dbsize.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.6")
            echo "Executando script: Últimos jobs..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/jobs.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.7")
            echo "Executando script: Tempo online..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/tempo_online.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "3.8")
            echo "Executando script: Versão do Oracle..."
            sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/version.sql
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "4.1")
            echo "Exibindo informações gerais do sistema..."
            echo "Nome do servidor: $(hostname)"
            echo "Sistema Operacional: $(uname -o 2>/dev/null || uname -s)"
            IP=$(hostname -I 2>/dev/null | awk '{print $1}')
            echo "IP: ${IP:-não identificado}"
            echo "Tempo online: $(uptime -p)"
            echo ""
            echo "Informações de CPU:"
            lscpu | grep -E '^(CPU\(s\):|On-line CPU\(s\) list:|Thread\(s\) per core:|Core\(s\) per socket:|Socket\(s\):|Model name:)'
            echo ""
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "4.2")
            echo "Abrindo o Alert log com vim..."
            vim "$ALERT_LOG"
            ;;
        "4.3")
            echo "Acompanhando o Alert log (tail -f)..."
            tail -f "$ALERT_LOG"
            ;;
        "4.4")
            echo "Verificando espaço em disco..."
            df -h
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "4.5")
            echo "Verificando load do sistema..."
            uptime
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "4.6")
            echo "Monitorando recursos (top)..."
            top
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        "4.7")
            echo "Checando logs do sistema (/var/log/messages)..."
            less /var/log/messages
            ;;
        "4.8")
            echo "Verificando status do Listener (via SO)..."
            lsnrctl status
            read -n1 -s -r -p "Pressione qualquer tecla para voltar ao menu..."
            ;;
        *)
            echo "Opção inválida! Tente novamente."
            sleep 1
            ;;
    esac
done

