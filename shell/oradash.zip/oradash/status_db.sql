set lines 400
set pages 200
prompt ========================================================================
prompt == Mostra o status das instancias do database
prompt ========================================================================
prompt


col host_name form a20
col instance_name form a20
COL startup_time FORM A20

SELECT instance_number,
       host_name,
       instance_name,
       to_char(startup_time,'DD/MM/RRRR HH24:MI:SS') startup_time,
       status,
       database_status,
       database_type
FROM gv$instance;
