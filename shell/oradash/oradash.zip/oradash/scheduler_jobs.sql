-- Lista todos os jobs do Scheduler
SET PAGESIZE 100
set lines 400
COLUMN owner       FORMAT A15
COLUMN job_name    FORMAT A30
COLUMN enabled     FORMAT A10
COLUMN state       FORMAT A10
COLUMN last_start_date FORMAT A20
COLUMN next_run_date   FORMAT A20

SELECT owner,
       job_name,
       enabled,
       state,
       TO_CHAR(last_start_date, 'DD/MM/YYYY HH24:MI:SS') AS last_start_date,
       TO_CHAR(next_run_date,   'DD/MM/YYYY HH24:MI:SS') AS next_run_date
FROM dba_scheduler_jobs
ORDER BY owner, job_name;

