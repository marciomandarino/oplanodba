set lines 400
set pages 200
prompt ========================================================================
prompt == Exibe as tablespaces do banco em GB
prompt ========================================================================
prompt

-- Summary Report for Tablespaces in GB
TTITLE CENTER 'Summary Report for Tablespaces (GB)'

COLUMN "Tablespace"      HEADING 'Tablespace'       FORMAT A25
COLUMN "Pct Used %"      HEADING 'Pct Used %'      FORMAT A15
COLUMN "Curr Size (GB)"  HEADING 'Curr Size (GB)'  FORMAT 999,999,999.9
COLUMN "Used (GB)"       HEADING 'Used (GB)'       FORMAT 999,999,999.9
COLUMN "Free (GB)"       HEADING 'Free (GB)'       FORMAT 999,999,999.9
COLUMN "Max Size (GB)"   HEADING 'Max Size (GB)'   FORMAT 999,999,999.9
COLUMN "Max Free (GB)"   HEADING 'Max Free (GB)'   FORMAT 999,999,999.9
COLUMN "Tot Files"       HEADING 'Tot Files'       FORMAT 999,999,999

-- Permanent tablespaces (datafiles)
SELECT
    df.tablespace_name AS "Tablespace",
    TO_CHAR(ROUND((df.gbytes_alloc - fs.free_space_gb) / df.maxgbytes * 100, 1),'999,999,999.9') || '%' AS "Pct Used %",
    df.gbytes_alloc    AS "Curr Size (GB)",
    ROUND(df.gbytes_alloc - fs.free_space_gb, 1) AS "Used (GB)",
    ROUND(fs.free_space_gb, 1)           AS "Free (GB)",
    df.maxgbytes       AS "Max Size (GB)",
    ROUND(df.maxgbytes - (df.gbytes_alloc - fs.free_space_gb), 1) AS "Max Free (GB)",
    df.tot_files       AS "Tot Files"
FROM (
    SELECT
      tablespace_name,
      COUNT(*) AS tot_files,
      ROUND(SUM(bytes) / 1024/1024/1024, 1) AS gbytes_alloc,
      ROUND(SUM(CASE WHEN autoextensible='YES' AND maxbytes>bytes THEN maxbytes ELSE bytes END) / 1024/1024/1024, 1) AS maxgbytes
    FROM dba_data_files
    GROUP BY tablespace_name
) df
JOIN (
    SELECT tablespace_name, ROUND(SUM(bytes) / 1024/1024/1024, 1) AS free_space_gb
    FROM dba_free_space
    GROUP BY tablespace_name
) fs ON df.tablespace_name = fs.tablespace_name
UNION ALL
-- Temporary tablespaces (tempfiles)
SELECT
    df.tablespace_name AS "Tablespace",
    TO_CHAR(ROUND((df.gbytes_alloc - fs.free_space_gb) / df.maxgbytes * 100, 1),'999,999,999.9') || '%' AS "Pct Used %",
    df.gbytes_alloc    AS "Curr Size (GB)",
    ROUND(df.gbytes_alloc - fs.free_space_gb, 1) AS "Used (GB)",
    ROUND(fs.free_space_gb, 1)           AS "Free (GB)",
    df.maxgbytes       AS "Max Size (GB)",
    ROUND(df.maxgbytes - (df.gbytes_alloc - fs.free_space_gb), 1) AS "Max Free (GB)",
    df.tot_files       AS "Tot Files"
FROM (
    SELECT
      tablespace_name,
      COUNT(*) AS tot_files,
      ROUND(SUM(bytes) / 1024/1024/1024, 1) AS gbytes_alloc,
      ROUND(SUM(CASE WHEN autoextensible='YES' AND maxbytes>bytes THEN maxbytes ELSE bytes END) / 1024/1024/1024, 1) AS maxgbytes
    FROM dba_temp_files
    GROUP BY tablespace_name
) df
JOIN (
    SELECT tablespace_name, ROUND(SUM(free_space) / 1024/1024/1024, 1) AS free_space_gb
    FROM dba_temp_free_space
    GROUP BY tablespace_name
) fs ON df.tablespace_name = fs.tablespace_name
ORDER BY 2 DESC;

TTITLE OFF

