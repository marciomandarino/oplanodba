#!/bin/bash

# ANSI Colors (usando escapes ANSI)
BLUE=$'\e[34m'
RED=$'\e[31m'
GREEN=$'\e[32m'
CYAN=$'\e[36m'
RESET=$'\e[0m'

# Header configuration
WIDTH=134
BORDER=$(printf '%*s' "$WIDTH" '' | tr ' ' '#')

# Center header text (ORADASH em azul)
center_header() {
    local text="$1"
    local display="$text"
    if [[ "$text" == "ORADASH" ]]; then
        display="${BLUE}${text}${RESET}"
    fi
    local inner=$((WIDTH-2))
    local len=${#text}
    local pad=$(((inner - len)/2))
    local extra=$(((inner - len)%2))
    printf "#%*s%s%*s#\n" "$pad" "" "$display" "$((pad+extra))" ""
}

# Imprime o cabeçalho
print_header() {
    clear
    echo "$BORDER"
    center_header "ORADASH"
    center_header "Oracle Interactive Dashboard and Tools"
    echo "$BORDER"
}

# Pausa até tecla
pause() {
    read -n1 -s -r -p "Pressione qualquer tecla para continuar..." </dev/tty
}

# Submenu Database
db_menu() {
    print_header; echo
    echo "DATABASE:"; echo
    echo "1.1) Info. do Database         1.2) Status das instâncias"
    echo "1.3) Tablespaces               1.4) PDBs"
    echo "1.5) Ocupação do Database      1.6) Últimos jobs"
    echo "1.7) Tempo online              1.8) Versão do Oracle"
    echo "1.9) Jobs do Scheduler         1.10) Parâmetros do Banco"
    echo "1.11) Sessões                  1.12) Maiores segmentos"
    echo "1.13) Espaço no ASM"
    echo ""
    echo "B) Voltar ao menu principal"
    echo ""
    echo ""
    read -p "Escolha: " o </dev/tty
    case "$o" in
        1.1) cmd="@${SQLPATH}/oradash/aonde.sql";;
        1.2) cmd="@${SQLPATH}/oradash/status_db.sql";;
        1.3) cmd="@${SQLPATH}/oradash/ts.sql";;
        1.4) cmd="@${SQLPATH}/oradash/pdb_info.sql";;
        1.5) cmd="@${SQLPATH}/oradash/dbsize.sql";;
        1.6) cmd="@${SQLPATH}/oradash/jobs.sql";;
        1.7) cmd="@${SQLPATH}/oradash/tempo_online.sql";;
        1.8) cmd="@${SQLPATH}/oradash/version.sql";;
        1.9) cmd="@${SQLPATH}/oradash/scheduler_jobs.sql";;
        1.10)
            clear
            sqlplus / as sysdba "@${SQLPATH}/oradash/params.sql"
            pause
            db_menu
            return
            ;;
        1.11) cmd="@${SQLPATH}/oradash/sessions.sql";;
        1.12) cmd="@${SQLPATH}/oradash/top_segments.sql";;
        1.13) cmd="@${SQLPATH}/oradash/asm_space.sql";;
        [Bb]) main_menu; return;;
        *) db_menu; return;;
    esac
    
    # Para as opções que usam cmd
    clear
    sqlplus -s / as sysdba <<EOF
$cmd
EXIT
EOF
    
    pause
    db_menu
}

# Submenu Backup
backup_menu() {
    print_header; echo
    echo "BACKUP:"; echo
    echo "2.1) Backups (24h)      	2.2) Archives (24h)"
    echo "2.3) Backups Full/Incr  	2.4) Espaço na FRA"
    echo "2.5) Progresso do Backup"
    echo ""
    echo "B) Voltar ao menu principal"
    echo ""
    echo ""
    read -p "Escolha: " o </dev/tty
    case "$o" in
        2.1) cmd="@${SQLPATH}/oradash/backup_day.sql";;
        2.2) cmd="@${SQLPATH}/oradash/archives_lastday.sql";;
        2.3) cmd="@${SQLPATH}/oradash/backup_week.sql";;
        2.4) cmd="@${SQLPATH}/oradash/fra.sql";;
        2.5) cmd="@${SQLPATH}/oradash/backup_progress.sql";;
	[Bb]) main_menu; return;;
        *) backup_menu; return;;
    esac
    clear
    sqlplus -s / as sysdba <<EOF
$cmd
EXIT
EOF
    pause; backup_menu
}

# Submenu Performance
perf_menu() {
    print_header; echo
    echo "PERFORMANCE:"; echo
    echo "3.1) Load         	3.2) Relatório ASH"
    echo "3.3) Waits        	3.4) AWR (última hora)"
    echo "3.5) AWR Full     	3.6) Bloqueios ativos"
    echo "3.7) Sessões      	3.8) Memória (SGA/PGA)"
    echo ""
    echo "B) Voltar ao menu principal"
    echo ""
    echo ""
    read -p "Escolha: " o </dev/tty
    case "$o" in
        3.1) clear; sqlplus / as sysdba "@${SQLPATH}/oradash/load.sql"; pause; perf_menu; return;;
        3.2) clear; sqlplus / as sysdba "@${SQLPATH}/oradash/ash_report.sql"; pause; perf_menu; return;;
	3.3) clear; sqlplus / as sysdba "@${SQLPATH}/oradash/ash.sql"; pause; perf_menu; return;;
        3.4) cmd="@${SQLPATH}/oradash/awr_1hora.sql";;
        3.5) cmd="@${SQLPATH}/oradash/awr.sql";;
        3.6) cmd="@$ORACLE_HOME/rdbms/admin/utllockt.sql";;
        3.7) cmd="@${SQLPATH}/oradash/active_sessions.sql";;
        3.8) cmd="@${SQLPATH}/oradash/memoria.sql";;
        [Bb]) main_menu; return;;
        *) perf_menu; return;;
    esac
    clear
    sqlplus -s / as sysdba <<EOF
$cmd
EXIT
EOF
    pause; perf_menu
}

# Submenu SO
so_menu() {
    print_header; echo
    echo "SISTEMA OPERACIONAL:"; echo
    echo "4.1) Resumo                   4.2) Alert log (vim)"
    echo "4.3) Alert log (tail -f)      4.4) Espaço em disco"
    echo "4.5) Load                     4.6) Monitoramento (top)"
    echo "4.7) Cron Jobs                4.8) Listener (via SO)"
    echo ""
    echo "B) Voltar ao menu principal"
    echo ""
    echo ""
    read -p "Escolha: " o </dev/tty
    case "$o" in
        4.1) hostname; uname -a; uptime;;
        4.2) ADRCI_HOME=$(adrci exec="show homes" | grep "$ORACLE_SID"); vi "$ORACLE_BASE/$ADRCI_HOME/trace/alert_${ORACLE_SID}.log";;
        4.3) ADRCI_HOME=$(adrci exec="show homes" | grep "$ORACLE_SID"); tail -f "$ORACLE_BASE/$ADRCI_HOME/trace/alert_${ORACLE_SID}.log";;
        4.4) df -h;;
        4.5) uptime;;
        4.6) top;;
        4.7) crontab -l;;
        4.8) lsnrctl status;;
        [Bb]) main_menu; return;;
        *) so_menu; return;;
    esac
    pause; so_menu
}

# Alternar Database
alternar_database() {
    print_header; echo
    echo "Alternar Database - Selecione SID"; echo
    dbs=(); homes=()
    while IFS=: read -r sid home auto; do
        [[ -z "$sid" || "$sid" =~ ^# ]] && continue
        dbs+=("$sid"); homes+=("$home")
    done < <(grep -Ev '^#|^$' /etc/oratab)
    for idx in "${!dbs[@]}"; do
        sid=${dbs[idx]}; home=${homes[idx]}
        [[ $(pgrep -f "ora_pmon_${sid}") ]] && col=$GREEN || col=$RED
        mark="$sid"; [[ "$sid" == "$ORACLE_SID" ]] && mark="${sid}*"
        printf "%2d) %b%-10s%b Home: %s\n" $((idx+1)) "$col" "$mark" "$RESET" "$home"
    done
    echo "0) Voltar ao menu principal"; echo
    read -p "Opção: " sel </dev/tty
    [[ "$sel" -eq 0 ]] && main_menu
    idx=$((sel-1))
    export ORACLE_SID=${dbs[idx]}
    export ORACLE_HOME=${homes[idx]}
    . oraenv <<< "$ORACLE_SID"
    pause; main_menu
}

# Conectar PDB
connect_pdb() {
    print_header; echo
    echo "Conectar em PDB:"; echo
    mapfile -t pdbs < <(sqlplus -s / as sysdba <<EOF
SET HEAD OFF FEEDBACK OFF PAGESIZE 0 ECHO OFF
SELECT 'CDB$ROOT' FROM DUAL
UNION ALL
SELECT name FROM v\$pdbs;
EXIT
EOF
    )
    for i in "${!pdbs[@]}"; do
        printf "%2d) %s\n" $((i+1)) "${pdbs[i]}"
    done
    echo "0) Voltar ao menu principal"; echo
    read -p "Opção: " sel </dev/tty
    [[ "$sel" -eq 0 ]] && main_menu
    idx=$((sel-1))
    [[ $idx -eq 0 ]] && unset ORACLE_PDB_SID || export ORACLE_PDB_SID="${pdbs[idx]}"
    pause; main_menu
}

# Créditos
credits_menu() {
    print_header
    echo
    echo "CRÉDITOS:"; echo
    echo "Desenvolvido por: Seu Nome"
    echo "Email: seu.email@dominio.com"; echo
    pause; main_menu
}

# Função principal definida após todas as submenus
main_menu() {
    print_header
    echo
    printf "ORACLE_HOME: %s | ORACLE_SID: %s" "$ORACLE_HOME" "$ORACLE_SID"
    [[ -n "$ORACLE_PDB_SID" ]] && printf " | ORACLE_PDB_SID: %s" "$ORACLE_PDB_SID"
    echo
    echo
    echo -n "Databases no oratab: "
    for sid in $(grep -Ev '^#|^$' /etc/oratab | cut -d: -f1); do
        if pgrep -f "ora_pmon_${sid}" &>/dev/null; then
            printf "${GREEN}%s${RESET}  " "$sid"
        else
            printf "${RED}%s${RESET}  " "$sid"
        fi
    done
    echo
    echo "$(printf '%*s' "$WIDTH" '' | tr ' ' '_')"
    echo
    echo -e "${CYAN}FERRAMENTAS ÚTEIS:${RESET}"
    echo "S) SQLPLUS   R) RMAN   A) ADRCI   O) ORATOP"
    echo
    echo "1) Database"
    echo "2) Backup"
    echo "3) Performance"
    echo "4) Sistema Operacional"
    echo
    echo "0) Sair    D) Alternar Database    P) Alternar PDB    99) Créditos"
    echo
    read -p "Escolha: " opt </dev/tty
    case "$opt" in
        S|s) clear; sqlplus / as sysdba ;;  R|r) clear; rman target / ;;
        A|a) clear; adrci ;;  O|o) clear; $ORACLE_HOME/suptools/oratop/oratop -rf / as sysdba || true;;
        1) clear; db_menu ;;  2) clear; backup_menu ;;  3) clear; perf_menu ;;  4) clear; so_menu;;
        D|d) clear; alternar_database ;;  P|p) clear; connect_pdb ;;  99) clear; credits_menu ;;  0) exit 0;;
    esac
    pause; main_menu
}

# Inicia aplicação
main_menu
'''

# Write script
path = '/mnt/data/oradash.sh'
with open(path, 'w') as f:
    f.write(script)
os.chmod(path, 0o755)


