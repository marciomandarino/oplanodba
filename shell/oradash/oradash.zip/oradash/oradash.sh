#!/bin/bash

# ANSI Colors
BLUE=$'\e[34m'
RED=$'\e[31m'
GREEN=$'\e[32m'
MAGENTA=$'\e[35m'
CYAN=$'\e[36m'
YELLOW=$'\e[33m'
RESET=$'\e[0m'

# Header configuration
WIDTH=134
BORDER=$(printf '%*s' "$WIDTH" '' | tr ' ' '#')

# Center header text (ORADASH in blue)
center_header() {
    local text="$1"
    local display_text="$text"
    if [[ "$text" == "ORADASH" ]]; then
        display_text="${BLUE}${text}${RESET}"
    fi
    local inner_width=$((WIDTH - 2))
    local text_length=${#text}
    local padding=$(( (inner_width - text_length) / 2 ))
    local extra=$(( (inner_width - text_length) % 2 ))
    printf "#%*s%s%*s#\n" "$padding" "" "$display_text" "$((padding + extra))" ""
}

while true; do
    clear
    # Header always active
    echo "$BORDER"
    center_header "ORADASH"
    center_header "Oracle Interactive Dashboard and Tools"
    echo "$BORDER"
    echo

    # Environment info
    printf "ORACLE_HOME: %s | ORACLE_SID: %b%s%b" "${ORACLE_HOME^^}" "$MAGENTA" "${ORACLE_SID^^}" "$RESET"
    if [[ -n "$ORACLE_PDB_SID" ]]; then
        printf " | ORACLE_PDB_SID: %b%s%b" "$CYAN" "${ORACLE_PDB_SID^^}" "$RESET"
    fi
    echo
    echo

    # Databases list
    echo -n "Databases encontrados no oratab: "
    for sid in $(grep -Ev '^#|^$' /etc/oratab | cut -d: -f1); do
        if pgrep -f "ora_pmon_${sid}" &>/dev/null; then
            printf "${GREEN}%s${RESET}  " "$sid"
        else
            printf "${RED}%s${RESET}  " "$sid"
        fi
    done
    echo
    echo "$(printf '%*s' "$WIDTH" '' | tr ' ' '_')"
    echo

    # Menu Categories
    echo -e "${CYAN}FERRAMENTAS ÚTEIS:${RESET}"
    echo "S) SQLPLUS                    R) RMAN                     A) ADRCI                            O) ORATOP"
    echo
    echo -e "${CYAN}BACKUP/RECOVERY:${RESET}"
    echo "1.1) Backups (24h)            1.2) Archives (24h)         1.3) Backups Full/Incr (7 dias)     1.4) Espaço na FRA"
    echo
    echo -e "${CYAN}PERFORMANCE:${RESET}"
    echo "2.1) Load do banco            2.2) Relatório ASH          2.3) Waits do banco                 2.4) AWR Report (última hora)"
    echo "2.5) AWR Report               2.6) Bloqueios ativos       2.7) Sessões ativas                 2.8) Memória (SGA/PGA)"
    echo
    echo -e "${CYAN}INFORMAÇÕES DO BANCO:${RESET}"
    echo "3.1) Info. do Database        3.2) Status das instâncias  3.3) Tablespaces                    3.4) PDBs"
    echo "3.5) Ocupação do Database     3.6) Últimos jobs           3.7) Tempo online                   3.8) Versão do Oracle"
    echo
    echo -e "${CYAN}SO:${RESET}"
    echo "4.1) Resumo do Sistema        4.2) Alert log (vim)        4.3) Alert log (tail -f)            4.4) Espaço em disco"
    echo "4.5) Load do sistema          4.6) Monitoramento (top)    4.7) Cron Jobs                      4.8) Listener (via SO)"
    echo
    # Final options: exit, switch DB, connect PDB, credits
    echo -e "0) Sair                       ${GREEN}D) Alternar Database${RESET}        ${YELLOW}P) Conectar PDB${RESET}        99) Créditos"
    echo
    read -p "Escolha uma opção: " opcao
    clear

    case "$opcao" in
        # SQL*Plus
        [Ss])
            sqlplus / as sysdba
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # RMAN
        [Rr])
            rman target /
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # ADRCI
        [Aa])
            adrci
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # ORATOP
        [Oo])
            $ORACLE_HOME/suptools/oratop/oratop -rf / as sysdba
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # Backup/Recovery
        "1.1") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/backup_day.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "1.2") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/archives_lastday.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "1.3") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/backup_week.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "1.4") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/fra.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # Performance
        "2.1")
            read -p "Intervalo (minutos) para Load do banco: " NUM_MINUTES </dev/tty
            sqlplus -s / as sysdba <<EOF
SET ECHO OFF VERIFY OFF FEEDBACK ON
DEFINE NUM_MINUTES=$NUM_MINUTES
@${SQLPATH}/oradash/load.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.2")
            read -p "Quantos minutos para análise do ASH? " ASH_MINUTES </dev/tty
            sqlplus -s / as sysdba <<EOF
DEFINE MINUTES=$ASH_MINUTES
@${SQLPATH}/oradash/ash_report.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.3")
            script -qfc "sqlplus / as sysdba @${SQLPATH}/oradash/ash.sql" /dev/null
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.4") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/awr_1hora.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.5") script -qfc "sqlplus / as sysdba @${SQLPATH}/oradash/awr.sql" /dev/null
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.6") sqlplus -s / as sysdba <<EOF
@$ORACLE_HOME/rdbms/admin/utllockt.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.7") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/active_sessions.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "2.8") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/memoria.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # Informações do Banco
        "3.1") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/aonde.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.2") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/status_db.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.3") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/ts.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.4") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/pdb_info.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.5") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/dbsize.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.6") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/jobs.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.7") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/tempo_online.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "3.8") sqlplus -s / as sysdba <<EOF
@${SQLPATH}/oradash/version.sql
exit
EOF
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # SO
        "4.1")
            echo "Resumo do Sistema:"; hostname; uname -a; uptime;
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;
        "4.2") vim "$ALERT_LOG";;
        "4.3") tail -f "$ALERT_LOG";;
        "4.4") df -h; read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty;;
        "4.5") uptime; read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty;;
        "4.6") top; read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty;;
        "4.7") crontab -l; read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty;;
        "4.8") lsnrctl status; read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty;;

        # Switch Database
        [Dd])
            # Alternar Database logic here
            ;;

                # Connect PDB
        [Pp])
            clear
            echo "PDB - Selecione um container ou PDB (1=root)"
            echo
            mapfile -t pdbs < <(
                sqlplus -s / as sysdba <<EOF
SET HEAD OFF FEEDBACK OFF PAGESIZE 0 ECHO OFF
SELECT 'CDB$ROOT' FROM DUAL
UNION ALL
SELECT name FROM v\$pdbs;
EXIT
EOF
            )
            for i in "${!pdbs[@]}"; do
                idx=$((i+1))
                name=$(echo "${pdbs[i]}" | xargs)
                printf "%2d) %s
" "$idx" "$name"
            done
            echo " 0) Voltar"
            echo
            read -p "Opção: " choice </dev/tty
            if [[ "$choice" -eq 0 ]]; then
                continue
            fi
            sel=$((choice-1))
            if [[ "$sel" -eq 0 ]]; then
                unset ORACLE_PDB_SID
                echo "Container root selecionado, ORACLE_PDB_SID resetado."
            else
                export ORACLE_PDB_SID=${pdbs[sel]}
                echo "PDB selecionado: $ORACLE_PDB_SID"
            fi
            read -n1 -s -r -p "Pressione qualquer tecla para continuar..." </dev/tty
            ;;


        # Credits
        99)
            echo "================================"
            echo "            CRÉDITOS            "
            echo "================================"
            echo "Desenvolvido por: Seu Nome"
            echo "Email: seu.email@dominio.com"
            echo "GitHub: https://github.com/seunome"
            read -n1 -s -r -p "Pressione qualquer tecla para voltar..." </dev/tty
            ;;

        # Exit or invalid
        0) break;;
        *) echo "Opção inválida!"; sleep 1;;
    esac
done

