set lines 400
set pages 200
prompt ========================================================================
prompt == Mostra as informacoes sobres os pdbs do container atual
prompt ========================================================================
prompt


SET VERIFY OFF
SET FEEDBACK OFF
col OPEN_MODE form a20
col name form a30
col OPEN_TIME form a40


select name,OPEN_MODE,OPEN_TIME,ROUND(TOTAL_SIZE/1024/1024/1024,1) size_gb from v$pdbs;
