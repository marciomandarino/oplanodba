-- Top 10 maiores segmentos por espaço utilizado (MB)
SET PAGESIZE 100
SET LINES 400
COLUMN owner        FORMAT A15
COLUMN segment_name FORMAT A30
COLUMN segment_type FORMAT A15
COLUMN size_gb      FORMAT 999,999,999.9

SELECT owner,
       segment_name,
       segment_type,
       ROUND(bytes/1024/1024/1024,1) AS size_gb
FROM dba_segments
ORDER BY bytes DESC
FETCH FIRST 10 ROWS ONLY;

