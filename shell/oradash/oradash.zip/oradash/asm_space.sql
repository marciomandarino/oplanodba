-- Espaço livre e total em todos os diskgroups ASM
SET PAGESIZE 100
COLUMN group_number FORMAT 999
COLUMN name         FORMAT A15
COLUMN total_mb     FORMAT 999,999,999.9
COLUMN free_mb      FORMAT 999,999,999.9
COLUMN pct_free     FORMAT 999.9

SELECT group_number,
       name,
       total_mb,
       free_mb,
       ROUND((free_mb/total_mb)*100,1) AS pct_free
FROM v$asm_diskgroup;

