set lines 400
set pages 200
prompt ========================================================================
prompt == Ocupacao do database em GB
prompt ========================================================================
prompt

COLUMN "Logical Size"            HEADING 'Logical| Size'             FORMAT 999,999,999.9
COLUMN "Datafiles Size"          HEADING 'Datafiles| Size'           FORMAT 999,999,999.9
COLUMN "Free Space in Datafiles" HEADING 'Free Space| in Datafiles'  FORMAT 999,999,999.9
COLUMN "Tempfiles Size"          HEADING 'Tempfiles| Size'           FORMAT 999,999,999.9
COLUMN "Redologs Size"           HEADING 'Redologs| Size'            FORMAT 999,999,999.9
COLUMN "Total Occupancy"         HEADING 'Total| Occupancy'          FORMAT 999,999,999.9

SELECT
  ROUND((SELECT SUM(bytes) FROM dba_segments) / 1024 / 1024 / 1024, 2) AS "Logical Size",
  ROUND((SELECT SUM(bytes) FROM dba_data_files) / 1024 / 1024 / 1024, 2) AS "Datafiles Size",
  ROUND((SELECT SUM(bytes) FROM dba_free_space) / 1024 / 1024 / 1024, 2) AS "Free Space in Datafiles",
  ROUND((SELECT SUM(bytes) FROM dba_temp_files) / 1024 / 1024 / 1024, 2) AS "Tempfiles Size",
  ROUND((SELECT SUM(bytes) FROM v$log) / 1024 / 1024 / 1024, 2) AS "Redologs Size",
  ROUND(((SELECT SUM(bytes) FROM dba_data_files) +
         (SELECT SUM(bytes) FROM dba_temp_files) +
         (SELECT SUM(bytes) FROM v$log)) / 1024 / 1024 / 1024, 2) AS "Total Occupancy"
FROM dual;

