set lines 400
set pages 200
prompt ========================================================================
prompt == Mostra o tamanho e ocupacao da SGA e PGA
prompt ========================================================================
prompt

set linesize 200
set pagesize 50

-- Define a formatação das colunas de saída
column instance_number heading "Inst Num" format 999
column snap_time       heading "Snapshot Time" format a20
column sga_usage_gb    heading "SGA Used (GB)" format a15
column sga_init_gb     heading "SGA Init (GB)" format a15
column sga_percent     heading "SGA % Used" format a10
column pga_usage_gb    heading "PGA Used (GB)" format a15
column pga_init_gb     heading "PGA Init (GB)" format a15
column pga_percent     heading "PGA % Used" format a10
column total_usage_gb  heading "Total Used (GB)" format a15

-- Consulta de utilização de memória (SGA/PGA) nos últimos 12 horas
SELECT 
  sn.INSTANCE_NUMBER as instance_number,
  to_char(sn.END_INTERVAL_TIME, 'dd/mm/yyyy hh24:mi') AS snap_time,
  -- SGA: utilização, valor de parâmetro e percentual
  to_char(round(sga.allo,1), 'FM9,999,990.9') AS sga_usage_gb,
  to_char(round((SELECT value/1024/1024/1024 
                 FROM v$parameter 
                WHERE name = 'sga_max_size'),1), 'FM9,999,990.9') AS sga_init_gb,
  to_char(round((sga.allo / (SELECT value/1024/1024/1024 
                              FROM v$parameter 
                             WHERE name = 'sga_max_size'))*100,1), 'FM990.0') || '%' AS sga_percent,
  -- PGA: utilização, valor de parâmetro e percentual
  to_char(round(pga.allo,1), 'FM9,999,990.9') AS pga_usage_gb,
  to_char(round((SELECT value/1024/1024/1024 
                 FROM v$parameter 
                WHERE name = 'pga_aggregate_target'),1), 'FM9,999,990.9') AS pga_init_gb,
  to_char(round((pga.allo / (SELECT value/1024/1024/1024 
                              FROM v$parameter 
                             WHERE name = 'pga_aggregate_target'))*100,1), 'FM990.0') || '%' AS pga_percent,
  -- Total de uso (SGA + PGA)
  to_char(round((sga.allo + pga.allo),1), 'FM9,999,990.9') AS total_usage_gb
FROM
  ( SELECT snap_id, INSTANCE_NUMBER, round(sum(bytes)/1024/1024/1024,3) AS allo
    FROM DBA_HIST_SGASTAT
    GROUP BY snap_id, INSTANCE_NUMBER
  ) sga,
  ( SELECT snap_id, INSTANCE_NUMBER, round(sum(value)/1024/1024/1024,3) AS allo
    FROM DBA_HIST_PGASTAT
    WHERE name = 'total PGA allocated'
    GROUP BY snap_id, INSTANCE_NUMBER
  ) pga,
  dba_hist_snapshot sn
WHERE sn.snap_id = sga.snap_id
  AND sn.INSTANCE_NUMBER = sga.INSTANCE_NUMBER
  AND sn.snap_id = pga.snap_id
  AND sn.INSTANCE_NUMBER = pga.INSTANCE_NUMBER
  AND sn.END_INTERVAL_TIME BETWEEN sysdate - (12/24) AND sysdate
ORDER BY sn.snap_id DESC, sn.INSTANCE_NUMBER, sn.END_INTERVAL_TIME DESC;

