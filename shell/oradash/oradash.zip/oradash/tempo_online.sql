set lines 400
set pages 200
prompt ========================================================================
prompt == Exibe ha quanto tempo as instancias estao no ar
prompt ========================================================================
prompt


-- Instance Uptime Report

TTITLE CENTER 'Instance Uptime Report'

COLUMN "Startup Time" HEADING 'Startup|Time'  FORMAT A20
COLUMN "Uptime"       HEADING 'Uptime'        FORMAT A40
COLUMN instance_name                          FORMAT A20

SELECT
  instance_name, 
  TO_CHAR(startup_time, 'DD/MM/YYYY HH24:MI:SS') AS "Startup Time",
  TRUNC(SYSDATE - startup_time) || ' days ' ||
  TRUNC(MOD((SYSDATE - startup_time)*24, 24)) || ' hours ' ||
  TRUNC(MOD((SYSDATE - startup_time)*24*60, 60)) || ' minutes ' ||
  TRUNC(MOD((SYSDATE - startup_time)*24*60*60, 60)) || ' seconds' AS "Uptime"
FROM gv$instance;

TTITLE OFF

