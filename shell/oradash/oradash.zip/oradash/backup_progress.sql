-- Backup in progress
prompt =============================================
prompt == Backup in progress
prompt =============================================

col ch format a30
col context format 9999999

SELECT s.inst_id, o.sid, client_info ch, context, sofar, totalwork,
       ROUND(sofar/totalwork*100,2) "% Complete"
  FROM gv$session_longops o JOIN gv$session s ON o.sid = s.sid
 WHERE opname LIKE 'RMAN%'
   AND opname NOT LIKE '%aggregate%'
   AND totalwork != 0
   AND sofar <> totalwork;

-- Progresso Geral
prompt =============================================
prompt == Progresso Geral
prompt =============================================

col dbsize_gb format 999,999,999.99
col input_gbytes format 999,999,999.99
col output_gbytes format 999,999,999.99
col est_complete format a30


col  "Resume" form a100
select
'recid.....................: '||recid||chr(10)||
'Output Device Type........: '||output_device_type||chr(10)||
'DDbsize (GB)..............: '||round(dbsize_mbytes/1024,1)||chr(10)||
'Input GB..................: '||round(input_bytes/1024/1024/1024,1)||chr(10)||
'Output GB.................: '||round(output_bytes/1024/1024/1024,1)||chr(10)||
'Compression...............: '||round((output_bytes/input_bytes*100),1)||chr(10)||
'Complete %................: '||round((mbytes_processed/dbsize_mbytes*100),1)||chr(10)||
'Est complete..............: '||to_char(start_time + (sysdate-start_time)/(mbytes_processed/dbsize_mbytes),'DD-MON-YYYY HH24:MI:SS') "Resume"
from v$rman_status rs
 , (select sum(bytes)/1024/1024 dbsize_mbytes from v$datafile)
 where status='RUNNING'
 and output_device_type is not null;
