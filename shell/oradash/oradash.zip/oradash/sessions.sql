-- Lista todas as sessões ativas
SET PAGESIZE 100
SET LINES 400
COLUMN sid       FORMAT 99999
COLUMN serial#   FORMAT 99999
COLUMN username  FORMAT A15
COLUMN status    FORMAT A10
COLUMN osuser    FORMAT A15
COLUMN machine   FORMAT A20
COLUMN program   FORMAT A33

SELECT sid,
       serial#,
       username,
       status,
       osuser,
       machine,
       program
FROM v$session
ORDER BY status, username;

