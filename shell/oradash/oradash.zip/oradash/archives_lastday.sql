set lines 400
set pages 200
prompt ========================================================================
prompt == Exibe os archives das ultimas 24 horas agrupado por hora
prompt ========================================================================
prompt


Prompt Printing information about Archive Generation

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES
set linesize 250

SET SPACE 1

set trimspool off
set pagesize 80

COMPUTE SUM LABEL TOTAL OF SIZE_GB      ON REPORT
COMPUTE AVG LABEL TOTAL OF SIZE_GB      ON REPORT
COMPUTE SUM LABEL TOTAL OF tot_archs    ON REPORT
col HOUR form a30


COMPUTE SUM OF tot_archs ON REPORT
COMPUTE SUM OF SIZE_GB ON REPORT
BREAK ON REPORT

select 
to_char(COMPLETION_TIME,'RRRR-MM-DD day HH24') HOUR, round(SUM(BLOCKS * BLOCK_SIZE)/1024/1024/1024,1) SIZE_GB , count(1) tot_archs
from V$ARCHIVED_LOG 
 WHERE COMPLETION_TIME >= TRUNC (SYSDATE) - 1
AND creator = 'ARCH'
group by to_char(COMPLETION_TIME,'RRRR-MM-DD day HH24') 
order by 1 ;



