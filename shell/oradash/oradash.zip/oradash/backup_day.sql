set lines 400
set pages 200
prompt ========================================================================
prompt == Lista os backups gerados nas ultimas 24 horas
prompt ========================================================================
prompt

col BACKUP_SIZE for a20
col "ELAPSED_TIME(HH24:MI:SS)"         HEADING 'ELAPSED_TIME|(HH24:MI:SS)'       FORMAT A20
col start_time for a25
col end_time for a25

SELECT
    input_type                                       "BACKUP_TYPE",
    status,
    to_char(start_time, 'MM/DD/YYYY:hh24:mi:ss')     AS start_time,
    to_char(end_time, 'MM/DD/YYYY:hh24:mi:ss')       AS end_time,
    floor(elapsed_seconds / 3600)
    || ':'
    || lpad(trunc(mod(elapsed_seconds, 3600) / 60), 2, '0')
    || ':'
    || lpad(trunc(mod(elapsed_seconds, 60)), 2, '0') AS "ELAPSED_TIME(HH24:MI:SS)",
    output_bytes_display                             "BACKUP_SIZE",
    output_device_type                               "OUTPUT_DEVICE"
FROM
    v$rman_backup_job_details
WHERE
        start_time > sysdate - 1
ORDER BY
    end_time DESC;