-- ash_report.sql
set lines 400
set pages 200
prompt ========================================================================
prompt == Gera um relatório do ASH no /tmp/ de um intervalo de minutos definido
prompt ========================================================================
prompt

set echo off heading on
column inst_num   heading "Inst Num"     new_value inst_num   format 99999
column inst_name  heading "Instance"     new_value inst_name  format a12
column db_name    heading "DB Name"      new_value db_name    format a12
column dbid       heading "DB Id"        new_value dbid       format 9999999999 just c

-- Captura informações da base e instância
select d.dbid    dbid,
       d.name    db_name,
       i.instance_number inst_num,
       i.instance_name   inst_name
  from v$database d, v$instance i;

-- Gera dinamicamente o nome do arquivo
column rptname new_value report_name noprint
select '/tmp/ash-'||to_char(sysdate,'DD-MM-YYYY_HH24-MI-SS')||'.html' as rptname
  from dual;

define file_name=&report_name

-- Define variáveis a partir do parâmetro MINUTES
define report_type='html'
define begin_time = -&MINUTES
define duration   = &MINUTES

-- Chama o script oficial do Oracle
@$ORACLE_HOME/rdbms/admin/ashrpt.sql

host clear
prompt O relatório ASH foi gerado em: &file_name

exit;

