set lines 400
set pages 200
prompt ========================================================
prompt == Exibe as sessoes ativas no banco
prompt ========================================================
prompt

COLUMN username         FORMAT A18
COLUMN spid             FORMAT A10
COLUMN machine          FORMAT A20
COLUMN logon_time       FORMAT A20
COLUMN PREV_EXEC_START  FORMAT A20
COLUMN event            FORMAT A30
COLUMN wait_class       FORMAT A20
COLUMN state            FORMAT A20
COLUMN program          FORMAT A20
COLUMN status           FORMAT A12
COLUMN lockwait         FORMAT A12
COLUMN sid              FORMAT 9999999999


select 
       s.inst_id,
       s.sid,
       s.serial#,
       NVL(s.username, '(oracle)') AS username,
       substr(s.machine,1,20) machine,
       s.status,
       s.wait_class, 
       substr(s.program,1,20) program,
       TO_CHAR(s.logon_Time,'DD-MON-YYYY HH24:MI:SS') AS logon_time
from
    gv$session s, (select con_id,name as pdb from v$pdbs) p
where
  s.con_id = p.con_id(+)
and    status='ACTIVE'
and type !='BACKGROUND'
and wait_class != 'Idle'
and sid != (select sid from v$mystat where rownum=1);

