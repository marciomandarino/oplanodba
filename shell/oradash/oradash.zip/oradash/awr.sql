set lines 400
set pages 200
prompt ========================================================================
prompt == Gera um relatorio do awr no /tmp/ de um intervalo de minutos definido
prompt ========================================================================
prompt


set echo off heading on
column inst_num heading "Inst Num" new_value inst_num format 99999;
column inst_name heading "Instance" new_value inst_name format a12;
column db_name heading "DB Name" new_value db_name format a12;
column dbid heading "DB Id" new_value dbid format 9999999999 just c;

-- Captura informações da base e da instância
select d.dbid dbid,
       d.name db_name,
       i.instance_number inst_num,
       i.instance_name inst_name
from v$database d,
     v$instance i;

-- Define variável fixa para o relatório
define report_type = 'active-html'
define num_days = 1


-- Solicita as datas de início e fim para filtragem dos snapshots
accept start_date prompt 'Entre a data de início (DD/MM/YYYY HH24:MI): '
accept end_date   prompt 'Entre a data de fim   (DD/MM/YYYY HH24:MI): '

-- Gera dinamicamente o nome do relatório com o formato: /tmp/awr-DD-MM-YYYY_HH24-MI-SS.html
column rptname new_value report_name noprint;
select '/tmp/awr-'||to_char(sysdate, 'DD-MM-YYYY_HH24-MI-SS')||'.html' as rptname from dual;

define file_name = &report_name

-- Captura dinamicamente o intervalo de snapshots com base nas datas informadas
column begin_snap new_value begin_snap
column end_snap new_value end_snap
select min(snap_id) as begin_snap,
       max(snap_id) as end_snap
from dba_hist_snapshot
where begin_interval_time between to_date('&start_date','DD/MM/YYYY HH24:MI')
                              and to_date('&end_date','DD/MM/YYYY HH24:MI');

PROMPT
PROMPT Gerando relatório AWR para os snapshots &begin_snap a &end_snap...
PROMPT

-- Executa o script padrão AWR
@$ORACLE_HOME/rdbms/admin/awrrpt.sql

-- Após a geração, limpa a tela e exibe o caminho completo do arquivo gerado
host clear
prompt O relatório AWR foi gerado e copiado para: &file_name

-- Remove as variáveis definidas
undefine report_type;
undefine report_name;
undefine begin_snap;
undefine end_snap;
undefine inst_num;
undefine dbid;
undefine db_name;
undefine inst_name;
undefine file_name;
undefine start_date;
undefine end_date;
undefine dflt_rpt;
undefine dbclmn;
undefine rpti_script;
undefine instance_numbers_or_all;
undefine awrgrpt_rptv;

exit;
