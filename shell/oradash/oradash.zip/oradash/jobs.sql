set lines 800
set pages 200
prompt ========================================================================
prompt == Lista os jobs do dbms_scheduler e suas ultimas execucoes
prompt ========================================================================
prompt

COLUMN job_name     FORMAT A30
COLUMN status       FORMAT A10
COLUMN start_date   FORMAT A20
COLUMN run_duration FORMAT A15
COLUMN error#       FORMAT 999,999
COLUMN elapsed_time FORMAT A25

SELECT job_name,
       status,
       TO_CHAR(actual_start_date, 'DD/MM/YYYY HH24:MI:SS') AS start_date,
       run_duration,
       error#,
       CASE 
         WHEN actual_start_date IS NOT NULL THEN
           EXTRACT(DAY FROM (SYSTIMESTAMP - actual_start_date)) || ' dias ' ||
           LPAD(EXTRACT(HOUR FROM (SYSTIMESTAMP - actual_start_date)), 2, '0') || ':' ||
           LPAD(EXTRACT(MINUTE FROM (SYSTIMESTAMP - actual_start_date)), 2, '0') || ':' ||
           LPAD(TRUNC(EXTRACT(SECOND FROM (SYSTIMESTAMP - actual_start_date))), 2, '0')
         ELSE 'Não disponível'
       END AS elapsed_time
FROM (
    SELECT job_name,
           status,
           actual_start_date,
           run_duration,
           error#,
           ROW_NUMBER() OVER (PARTITION BY job_name ORDER BY actual_start_date DESC) AS rn
    FROM dba_scheduler_job_run_details
)
WHERE rn = 1
ORDER BY job_name;



