accept v_param prompt 'Informe o parametro de inicialização: '

-- Exibe parâmetros de inicialização com filtro LIKE
set lines 400
SET PAGESIZE 100
col name            form a30
col value           form a30
col description     form a80
col default_value   form a30

SELECT name, value,  isdefault, description
FROM v$parameter
WHERE name LIKE lower('%&v_param%')
ORDER BY name;
exit;
