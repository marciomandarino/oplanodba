set lines 400
set pages 200
prompt ========================================================================
prompt == Lista os backups gerados na ultima semana (full/inc)
prompt ========================================================================
prompt

col BACKUP_SIZE for a20
Col ELAPSED_TIME form a20

SELECT
    input_type                                       "BACKUP_TYPE",
    status,
    to_char(start_time, 'MM/DD/YYYY:hh24:mi:ss')     AS start_time,
    to_char(end_time, 'MM/DD/YYYY:hh24:mi:ss')       AS end_time,
    floor(elapsed_seconds / 3600)
    || ':'
    || lpad(trunc(mod(elapsed_seconds, 3600) / 60), 2, '0')
    || ':'
    || lpad(trunc(mod(elapsed_seconds, 60)), 2, '0') AS "ELAPSED_TIME(HH24:MI:SS)",
    output_bytes_display                             "BACKUP_SIZE",
    output_device_type                               "OUTPUT_DEVICE"
FROM
    v$rman_backup_job_details
WHERE
        start_time > sysdate - 7
    AND input_type != 'ARCHIVELOG'
ORDER BY
    end_time DESC;